import{j as r}from"./vendor-react-t1fsld8M.js";import{B as b}from"./index-B_Rc7VcH.js";import{D as f,b as u,c as g,d as m}from"./AdminPageGuide-DW7N8Fcn.js";import{f as h,p as w}from"./vendor-date-DdRp2KlQ.js";import{bk as y,bl as j,a8 as v}from"./vendor-icons-BC3viSGH.js";function $(e,n,t){const o=t.map(i=>i.header).join(","),l=e.map(i=>t.map(c=>{const s=i[c.key],a=s==null?"":String(s);return a.includes(",")||a.includes('"')||a.includes(`
`)?`"${a.replace(/"/g,'""')}"`:a}).join(",")),d="\uFEFF"+[o,...l].join(`
`),p=new Blob([d],{type:"text/csv;charset=utf-8;"});R(p,`${n}_${h(new Date,"yyyy-MM-dd")}.csv`)}function k(e,n,t,o){const l=h(new Date,"dd/MM/yyyy 'às' HH:mm",{locale:w}),d=n.map(a=>`<tr>${t.map(x=>`<td style="border:1px solid #ddd;padding:6px 10px;font-size:12px;">${a[x.key]??""}</td>`).join("")}</tr>`).join(""),p=`
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>${e}</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 40px; color: #333; }
    h1 { font-size: 20px; margin-bottom: 4px; }
    .meta { color: #888; font-size: 12px; margin-bottom: 20px; }
    table { border-collapse: collapse; width: 100%; }
    th { background: #f5f5f5; border: 1px solid #ddd; padding: 8px 10px; text-align: left; font-size: 12px; font-weight: 600; }
    tr:nth-child(even) { background: #fafafa; }
    .footer { margin-top: 30px; font-size: 11px; color: #aaa; border-top: 1px solid #eee; padding-top: 10px; }
  </style>
</head>
<body>
  <h1>${e}</h1>
  <p class="meta">Gerado em ${l} · ${n.length} registros</p>
  <table>
    <thead><tr>${t.map(a=>`<th>${a.header}</th>`).join("")}</tr></thead>
    <tbody>${d}</tbody>
  </table>
  <div class="footer">Relatório gerado automaticamente pelo sistema administrativo.</div>
</body>
</html>`,i=new Blob([p],{type:"text/html"}),c=URL.createObjectURL(i),s=window.open(c,"_blank");s&&(s.onload=()=>{s.print()})}function R(e,n){const t=URL.createObjectURL(e),o=document.createElement("a");o.href=t,o.download=n,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(t)}const L=({data:e,columns:n,filename:t,title:o})=>e.length?r.jsxs(f,{children:[r.jsx(u,{asChild:!0,children:r.jsxs(b,{className:"admin-btn admin-btn-view gap-2",children:[r.jsx(y,{className:"h-4 w-4"}),"Exportar"]})}),r.jsxs(g,{align:"end",className:"liquid-glass text-white",children:[r.jsxs(m,{onClick:()=>$(e,t,n),className:"gap-2 cursor-pointer hover:bg-white/[0.06]",children:[r.jsx(j,{className:"h-4 w-4"}),"Exportar CSV"]}),r.jsxs(m,{onClick:()=>k(o,e,n),className:"gap-2 cursor-pointer hover:bg-white/[0.06]",children:[r.jsx(v,{className:"h-4 w-4"}),"Imprimir / PDF"]})]})]}):null;export{L as E};
